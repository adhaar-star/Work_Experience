Invisible Assassin WordPress Theme
GNU GPL v3
Copyrights 2015. Rohit Tripathi.
http://rohitink.com/


Invisible Assassin
=========

Invisible Assassin is a Minimalistic WordPress Theme, very lightweight and fast loading. But, still has all the features you need including a Responsive Slider, Social Icons, Multilevel Navigation, Optional Sidebar, Footer Widgets and Much More. This theme has been throughly tested with all Modern Mobile Platforms including Android, iPhone and Windows Phone and it works Flawlessly. Invisible Assassin is one of the Best Responsive Themes out there. NOTE: Invisible Assassin v2.0 contains major changes, existing users update with caution.


Getting Started
---------------

How to Install the Theme?

1. Go to WP Admin > Appearance > Themes > Add New.
2. Search for "Invisible Assassin".
3. Click on Install and Activate.

Alternatively,

1. Go to WP Admin > Appearance > Themes > Add New > Upload.
2. Upload the invisible-assassin.zip file, in which you found this README.txt
3. Click on Install and Activate.

Setting it Up
-------------

This theme is built using Customizer. So to Configure theme settings like Layout, Sliders, Social Icons, etc from 
	
	Dashboard > Appearance > Customizer	
	
	

Report Bugs / Theme Support
---------------------------

Invisible Assassin is a Brand new theme, and could contain some hidden bugs. So, if you find any please report them at the following URL:

http://rohitink.com/contact-me/


External Resources / Licenses
-----------------------------

This theme is 100% GPL. And any external resources used and bundled with the theme are also Fully Compatible with the GPL.

1. Font Awesome
	- Code under MIT License
	- Font under SIL OFL 1.1 
	- http://fortawesome.github.io/Font-Awesome/
	
2. Bootstrap
	- MIT License
	- http://getbootstrap.com
	
3. Hover.css
	- MIT License
	- http://ianlunn.github.io/Hover/
						
4. Nivo Slider
	- MIT LIcense
	- https://github.com/gilbitron/Nivo-Slider	
	
5. _S/Underscores Framework
	- GPL v2
	- http://underscores.me

6. Modernizer 			
	- MIT and BSD
	- http://modernizr.com
	
7. Responsive Menu
	- https://github.com/mattkersley/Responsive-Menu
	- MIT license
			
	

All Other Resources, apart from the ones mentioned above have been created by me fall under GPL v3 license of the theme.	

Screenshot Image Credits
------------------------

All the Images used in the Screenshot are Public Domain.
https://creativecommons.org/publicdomain/zero/1.0/

List of Images
	- http://pixabay.com/en/jellyfish-under-water-sea-ocean-698521/
	- http://pixabay.com/en/photographer-tourist-snapshot-407068/
	

		