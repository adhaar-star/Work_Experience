        </div> <!-- End main container -->
        <script type="text/javascript">
            $(document).ready(function () {
                $(".close").click(function () {
                    $(this).parent().slideUp();
                });
            });
        </script>
    </body>
</html>